#include <stdio.h>
#include <limits.h>

void ranges() {
  // implement this
}

int factorial1(int n) {
  int res = 1;
  // complete this
  return res;
}

int factorial2(int n) {
  int res = 1;
  // complete this
  return res;
}

int factorial3(int n) {
  int res = 1;
  // complete this
  return res;
}

int factorial4(int n) {
  // complete this
}


void types() {
  // implement this
}


// test code; do not modify
int main() {

  ranges();

  printf("factorial1(10) = %d\n", factorial1(10));
  printf("factorial2(10) = %d\n", factorial2(10));
  printf("factorial3(10) = %d\n", factorial3(10));
  printf("factorial4(10) = %d\n", factorial4(10));
  printf("\n");

  types();

  return 0;
}
