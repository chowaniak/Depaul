long loop(long x, int n) {
  return 2;
}
